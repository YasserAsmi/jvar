var files =
[
    [ "arr.h", null, null ],
    [ "json.h", null, null ],
    [ "jvar.h", null, null ],
    [ "str.h", null, null ],
    [ "util.h", null, null ],
    [ "var.h", null, null ]
];