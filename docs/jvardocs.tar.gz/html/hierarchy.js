var hierarchy =
[
    [ "jvar::BArray", "classjvar_1_1BArray.html", [
      [ "jvar::ObjArray< T >", "classjvar_1_1ObjArray.html", null ],
      [ "jvar::ObjArray< std::string >", "classjvar_1_1ObjArray.html", [
        [ "jvar::StrArray", "classjvar_1_1StrArray.html", null ]
      ] ]
    ] ],
    [ "jvar::Buffer", "classjvar_1_1Buffer.html", null ],
    [ "jvar::KeywordArray::Entry", "structjvar_1_1KeywordArray_1_1Entry.html", null ],
    [ "jvar::FixedStr< MAXFIXED >", "classjvar_1_1FixedStr.html", null ],
    [ "jvar::InterfaceImpl", "classjvar_1_1InterfaceImpl.html", null ],
    [ "jvar::Iter< T >", "classjvar_1_1Iter.html", null ],
    [ "jvar::KeywordArray", "classjvar_1_1KeywordArray.html", null ],
    [ "jvar::Parser", "classjvar_1_1Parser.html", [
      [ "jvar::JsonParser", "classjvar_1_1JsonParser.html", null ]
    ] ],
    [ "jvar::PropArray< T >", "classjvar_1_1PropArray.html", null ],
    [ "jvar::Variant", "classjvar_1_1Variant.html", null ]
];