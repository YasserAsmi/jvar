var structjvar_1_1KeywordArray_1_1Entry =
[
    [ "keyword", "structjvar_1_1KeywordArray_1_1Entry.html#ab580b852295e51a303d76961181f0931", null ],
    [ "value", "structjvar_1_1KeywordArray_1_1Entry.html#a33b6c98f659430d86d43cc75e55ac9f3", null ]
];