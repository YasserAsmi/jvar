var examples =
[
    [ "arrays.cpp", "arrays_8cpp-example.html", null ],
    [ "basics.cpp", "basics_8cpp-example.html", null ],
    [ "func.cpp", "func_8cpp-example.html", null ],
    [ "jsonparse.cpp", "jsonparse_8cpp-example.html", null ],
    [ "misc.cpp", "misc_8cpp-example.html", null ],
    [ "objs.cpp", "objs_8cpp-example.html", null ],
    [ "printv.cpp", "printv_8cpp-example.html", null ]
];