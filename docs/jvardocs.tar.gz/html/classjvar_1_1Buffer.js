var classjvar_1_1Buffer =
[
    [ "Buffer", "classjvar_1_1Buffer.html#ad0bbe1138ae95fd68bf6bc3eeff84608", null ],
    [ "~Buffer", "classjvar_1_1Buffer.html#aa66ac0214269a78ebc2512105be14dfc", null ],
    [ "alloc", "classjvar_1_1Buffer.html#a11ebbc89364becc705d5b2f47ab737ce", null ],
    [ "copyFrom", "classjvar_1_1Buffer.html#adeb05795e1b5f3d4260d708dd8c2be35", null ],
    [ "cptr", "classjvar_1_1Buffer.html#a8011ffdf9b37cee7ddd6f55546461a04", null ],
    [ "free", "classjvar_1_1Buffer.html#ad4d73010349c72bcaee3f8a374052c50", null ],
    [ "moveFrom", "classjvar_1_1Buffer.html#acf5813a064aa4de5351441cbe00d242a", null ],
    [ "ptr", "classjvar_1_1Buffer.html#a38cf6067f510a8d49604661aef08e458", null ],
    [ "readFile", "classjvar_1_1Buffer.html#a9dc63533db8f3876a63761015a539463", null ],
    [ "reAlloc", "classjvar_1_1Buffer.html#a1729f3e818cb2a07ef8c5d3a6fe419b0", null ],
    [ "size", "classjvar_1_1Buffer.html#a62e1b267df411073e523fec1688c63c6", null ]
];