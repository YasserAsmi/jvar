var searchData=
[
  ['add',['add',['../classjvar_1_1BArray.html#a8670832b33b4f38c366c0753af46f92a',1,'jvar::BArray::add()'],['../classjvar_1_1ObjArray.html#a6751d825aa7414bfc71f6b30f264d0a6',1,'jvar::ObjArray::add()'],['../classjvar_1_1PropArray.html#aadd7d81ed7369a49ca6e65f8a5d7d024',1,'jvar::PropArray::add()'],['../classjvar_1_1StrArray.html#a8223c6dea32f21c8b91c0bd15f6b122e',1,'jvar::StrArray::add()']]],
  ['addenv',['addEnv',['../classjvar_1_1Variant.html#ab401b6d479a304ed5bec21b393925f91',1,'jvar::Variant']]],
  ['addormodify',['addOrModify',['../classjvar_1_1BArray.html#af867dc6b8c316fb9ad9bf95dcdfc9564',1,'jvar::BArray::addOrModify()'],['../classjvar_1_1ObjArray.html#a89231be711dbba2e9530e6ed8f240bea',1,'jvar::ObjArray::addOrModify()'],['../classjvar_1_1PropArray.html#a9ab33c65dbd1201b04e6acf1407a2e50',1,'jvar::PropArray::addOrModify()']]],
  ['addproperty',['addProperty',['../classjvar_1_1Variant.html#a6e08ccf9274acf24d9929d30f7c5f829',1,'jvar::Variant']]],
  ['advance',['advance',['../classjvar_1_1Parser.html#ab25dde10e00de9186e1483d68d92391b',1,'jvar::Parser::advance()'],['../classjvar_1_1Parser.html#a83f7ace1b4ddeba284d4904a46d47e99',1,'jvar::Parser::advance(const char *match)']]],
  ['alloc',['alloc',['../classjvar_1_1Buffer.html#a11ebbc89364becc705d5b2f47ab737ce',1,'jvar::Buffer']]],
  ['append',['append',['../classjvar_1_1BArray.html#a990f0e82a8db716f3b7fbc0911348a89',1,'jvar::BArray::append()'],['../classjvar_1_1ObjArray.html#a2c32a2472d7f7e7f9231d3bfdeda4536',1,'jvar::ObjArray::append()'],['../classjvar_1_1Variant.html#a4454854d25660b90832d63f9b0581f7d',1,'jvar::Variant::append()']]]
];
