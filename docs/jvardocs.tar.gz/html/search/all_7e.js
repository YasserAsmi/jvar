var searchData=
[
  ['_7evariant',['~Variant',['../classjvar_1_1Variant.html#ad71fd7c6cf7707ecdd99a4f313cc2baf',1,'jvar::Variant']]]
];
