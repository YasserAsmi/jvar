var searchData=
[
  ['variant',['Variant',['../classjvar_1_1Variant.html',1,'jvar']]]
];
