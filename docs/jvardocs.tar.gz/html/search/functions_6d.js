var searchData=
[
  ['movefrom',['moveFrom',['../classjvar_1_1Buffer.html#acf5813a064aa4de5351441cbe00d242a',1,'jvar::Buffer']]]
];
