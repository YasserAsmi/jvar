var searchData=
[
  ['usefixedmem',['useFixedMem',['../classjvar_1_1BArray.html#a9cc25cb7f4c05aa860525c5cfa685c53',1,'jvar::BArray']]]
];
