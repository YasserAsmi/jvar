var searchData=
[
  ['mflags',['mFlags',['../classjvar_1_1BArray.html#a8d12beed4e4d2085a7b65e9b39bf770d',1,'jvar::BArray']]],
  ['movefrom',['moveFrom',['../classjvar_1_1Buffer.html#acf5813a064aa4de5351441cbe00d242a',1,'jvar::Buffer']]]
];
