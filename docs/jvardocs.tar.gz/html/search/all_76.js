var searchData=
[
  ['variant',['Variant',['../classjvar_1_1Variant.html',1,'jvar']]],
  ['variant',['Variant',['../classjvar_1_1Variant.html#ade369f36f2b73a3f80c3be00338b2cc2',1,'jvar::Variant::Variant()'],['../classjvar_1_1Variant.html#a7cb9dc261c82acf9e7e25ec604fa4f32',1,'jvar::Variant::Variant(longint i)'],['../classjvar_1_1Variant.html#a69f617a96022fdebadb8cf00a2f57df7',1,'jvar::Variant::Variant(int i)'],['../classjvar_1_1Variant.html#a3d3be30f7f56b68c412a11dcdb658762',1,'jvar::Variant::Variant(double d)'],['../classjvar_1_1Variant.html#a65819886d7a18584949c9695e185750e',1,'jvar::Variant::Variant(std::string s)'],['../classjvar_1_1Variant.html#a6d1c84812b019d21c4216282ac6f5601',1,'jvar::Variant::Variant(const char *s)'],['../classjvar_1_1Variant.html#a16c44e6f80df44d20975d9af8d109596',1,'jvar::Variant::Variant(Variant const &amp;src)']]]
];
