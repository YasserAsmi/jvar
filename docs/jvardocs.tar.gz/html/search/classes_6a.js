var searchData=
[
  ['jsonparser',['JsonParser',['../classjvar_1_1JsonParser.html',1,'jvar']]]
];
