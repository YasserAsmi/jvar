var searchData=
[
  ['barray',['BArray',['../classjvar_1_1BArray.html',1,'jvar']]],
  ['buffer',['Buffer',['../classjvar_1_1Buffer.html',1,'jvar']]]
];
