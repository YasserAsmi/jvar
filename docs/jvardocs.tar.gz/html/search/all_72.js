var searchData=
[
  ['readfile',['readFile',['../classjvar_1_1Buffer.html#a9dc63533db8f3876a63761015a539463',1,'jvar::Buffer']]],
  ['realloc',['reAlloc',['../classjvar_1_1Buffer.html#a1729f3e818cb2a07ef8c5d3a6fe419b0',1,'jvar::Buffer']]],
  ['remove',['remove',['../classjvar_1_1BArray.html#a29c8dcf1e6fd20e349d0eb76c34d6830',1,'jvar::BArray::remove(int pos)'],['../classjvar_1_1BArray.html#a381c6611fb8db5a02bb2dfbab1a3d16b',1,'jvar::BArray::remove(const void *elem)'],['../classjvar_1_1ObjArray.html#a88bafaddfcf8d0970f69a56f348f1099',1,'jvar::ObjArray::remove(const T *keyelem)'],['../classjvar_1_1ObjArray.html#aa2d0fefc39135ffb1a2408318469c328',1,'jvar::ObjArray::remove(int pos)'],['../classjvar_1_1PropArray.html#a95364834365947af7c72316e09a03c0c',1,'jvar::PropArray::remove()'],['../classjvar_1_1StrArray.html#ac504eb5255bb3dacb4ac5deab079f170',1,'jvar::StrArray::remove()']]],
  ['reserve',['reserve',['../classjvar_1_1BArray.html#abc89a4466c140655338333adeb4917b8',1,'jvar::BArray']]]
];
