var searchData=
[
  ['mflags',['mFlags',['../classjvar_1_1BArray.html#a8d12beed4e4d2085a7b65e9b39bf770d',1,'jvar::BArray']]]
];
