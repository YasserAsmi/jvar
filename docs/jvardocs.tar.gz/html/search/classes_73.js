var searchData=
[
  ['strarray',['StrArray',['../classjvar_1_1StrArray.html',1,'jvar']]]
];
