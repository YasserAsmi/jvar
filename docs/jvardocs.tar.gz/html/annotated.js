var annotated =
[
    [ "jvar::BArray", "classjvar_1_1BArray.html", "classjvar_1_1BArray" ],
    [ "jvar::Buffer", "classjvar_1_1Buffer.html", "classjvar_1_1Buffer" ],
    [ "jvar::KeywordArray::Entry", "structjvar_1_1KeywordArray_1_1Entry.html", "structjvar_1_1KeywordArray_1_1Entry" ],
    [ "jvar::FixedStr< MAXFIXED >", "classjvar_1_1FixedStr.html", "classjvar_1_1FixedStr" ],
    [ "jvar::InterfaceImpl", "classjvar_1_1InterfaceImpl.html", "classjvar_1_1InterfaceImpl" ],
    [ "jvar::Iter< T >", "classjvar_1_1Iter.html", "classjvar_1_1Iter" ],
    [ "jvar::JsonParser", "classjvar_1_1JsonParser.html", "classjvar_1_1JsonParser" ],
    [ "jvar::KeywordArray", "classjvar_1_1KeywordArray.html", "classjvar_1_1KeywordArray" ],
    [ "jvar::ObjArray< T >", "classjvar_1_1ObjArray.html", "classjvar_1_1ObjArray" ],
    [ "jvar::Parser", "classjvar_1_1Parser.html", "classjvar_1_1Parser" ],
    [ "jvar::PropArray< T >", "classjvar_1_1PropArray.html", "classjvar_1_1PropArray" ],
    [ "jvar::StrArray", "classjvar_1_1StrArray.html", "classjvar_1_1StrArray" ],
    [ "jvar::Variant", "classjvar_1_1Variant.html", "classjvar_1_1Variant" ]
];