var classjvar_1_1InterfaceImpl =
[
    [ "~InterfaceImpl", "classjvar_1_1InterfaceImpl.html#a261901bc05e43bb00cff27dc6ba30102", null ],
    [ "newImpl", "classjvar_1_1InterfaceImpl.html#aafc3caa098f0dd00ec6d2f9a3f48c718", null ]
];